﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassXamLib
{
    static class Constants
    {
        public const Dictionary<string, string> Methods = new Dictionary<string, string>()
        {
            {"VALIDATE", "Validation"}
        };

    }
}
