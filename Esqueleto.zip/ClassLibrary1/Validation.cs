﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassXamLib
{
    class Validation:AbsService
    {
        public Dictionary<string, object> executeService(Dictionary<string, string> data)
        {
            Dictionary<string, dynamic> result = new Dictionary<string, dynamic>();

            return result;
        }
    }
}
